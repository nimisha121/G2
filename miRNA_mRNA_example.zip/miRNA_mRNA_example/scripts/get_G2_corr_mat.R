### make sure that dep.data and indep.data have no annotation columns
### samples should be on rows and genes on columns


G2corr <- function(dep.data,indep.data){

### scale the data

dep.data = scale(dep.data,center = T, scale = T)
indep.data = scale(indep.data,center = T, scale = T)


corr_mat = matrix(0,ncol(dep.data),ncol(indep.data)) ## initialize the matrix

rownames(corr_mat) = colnames(dep.data)
colnames(corr_mat) = colnames(indep.data)

for (ci in  1:ncol(dep.data)){
          CNi = as.matrix(dep.data[,ci])   ### observations on single gene in dep.data
             for (ei in 1:ncol(indep.data)){
               EXi = as.matrix(indep.data[,ei])   ### observations on single gene in indep.data
               Sgi = (sum(diag(tcrossprod(CNi)%*%tcrossprod(EXi))))   ## G2 test statitic
               Sdi = (sum(diag(tcrossprod(CNi))))*(sum(diag(tcrossprod(EXi))))  ### for standardization
               corr_mat[ci,ei] = sqrt(Sgi/Sdi)*sign((lm(CNi~EXi)$coefficients)[2])  ### correlation type measure

          }
 } 

return(corr_mat)
}