####### Run G2

setwd(paste(home_dir,"/Scripts_submitted/miRNA_mRNA_example/scripts",sep = ""))
source("G2.R")
source("get_G2_corr_mat.R")


###### G2 for miRNA families

setwd(paste(home_dir,"/Scripts_submitted/miRNA_mRNA_example/data",sep = ""))

load("fam_names_mi.m.rna.RData")


p.val <- p.val_std <- c(0)
TS <- TS_std <- numeric(1001)

for(i in 1:length(fam_names)){

     load(paste("mir.data.fam",i,".RData",sep="")) ## samples on columns
     load(paste("mrna.data.fam",i,".RData",sep="")) ## samples on columns
     
     mir.data.G2 = mir.data.G2[,-1] ## remover the column with mir families
    
     ## dep.data = t(mrna.data.G2) to have samples on rows

     G2pval = G2(dep.data = t(mrna.data.G2), indep.data = t(mir.data.G2),grouping=F, stand=TRUE, nperm=1000)
     
     corr_mat = G2corr(dep.data = t(mrna.data.G2), indep.data = t(mir.data.G2))
     pval = t(as.matrix(G2pval$G2p))
     rownames(pval) = fam_names[i]
     p.val = rbind(p.val,pval)
     pval = t(as.matrix(G2pval$std_pval))
     rownames(pval) = fam_names[i]
     p.val_std = rbind(p.val_std,pval)
     ts = G2pval$test_stat
     rownames(ts) = fam_names[i]
     TS = rbind(TS,ts)
     ts = G2pval$std_test
     rownames(ts) = fam_names[i]
     TS_std = rbind(TS_std,ts)
     setwd(paste(home_dir,"/Scripts_submitted/miRNA_mRNA_example/results",sep = ""))
     save(corr_mat,file=paste("miRNA_mRNA_corr_mat_fam",i,".RData",sep=""))
     setwd(paste(home_dir,"/Scripts_submitted/miRNA_mRNA_example/data",sep = ""))
}
p.val = p.val[-1,]
p.val_std = p.val_std[-1]
TS = TS[-1,]
TS_std = TS_std[-1,]
setwd(paste(home_dir,"/Scripts_submitted/miRNA_mRNA_example/results",sep = ""))
save(p.val,file = "G2.pval.mirna.mrna.RData")
save(TS,file = "G2.TS.mirna.mrna.RData")
save(p.val_std,file = "G2.pval_std.mirna.mrna.RData")
save(TS_std,file = "G2.TS_std.mirna.mrna.RData")
