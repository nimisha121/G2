rm(list=ls())

library(reshape)
library(scales)
library(cherry)
library(lattice)

home_dir = "/Users/chaturve/Dropbox/jelle_project/G2data_scripts_2"


#### Run G2 and get results

setwd(paste(home_dir,"/Scripts_submitted/miRNA_mRNA_example/scripts",sep = ""))
source("run_G2.R")

##### PLot G2 and GT p-values, raw and adjusted Figure 4

setwd(paste(home_dir,"/Scripts_submitted/miRNA_mRNA_example/scripts",sep = ""))
source("G2_GT_pval_plots.R")

#### PLot the correlation heatmap Figure 5

setwd(paste(home_dir,"/Scripts_submitted/miRNA_mRNA_example/scripts",sep = ""))
source("plot_corr_heatmap.R")

