######### Plot correaltion heatmap G2 Figure 5 in the paper

setwd(paste(home_dir,"/Scripts_submitted/miRNA_mRNA_example/results",sep = ""))
pdf("Figure5.pdf")

par(mfrow=c(1,1))

fam = c(13,21)
#### 13 : PLOT 4 IN THE PAPER
#### 21: PLOT 5 IN THE PAPER

for (i in 1){

    #### PLot GT raw and adj p-values
    
    setwd(paste(home_dir,"/Scripts_submitted/miRNA_mRNA_example/data",sep = ""))

    load(paste("mir.data.fam",fam[i],".RData",sep="")) ## samples on columns
    load(paste("mrna.data.fam",fam[i],".RData",sep="")) ## samples on columns

    mir.data.G2 = mir.data.G2[,-1] ## remover the column with mir families

    setwd(paste(home_dir,"/Scripts_submitted/miRNA_mRNA_example/results",sep = ""))
    load(paste("miRNA_mRNA_corr_mat_fam",fam[i],".RData",sep=""))
    rownames(corr_mat) = rownames(mrna.data.G2)
    colnames(corr_mat) = rownames(mir.data.G2)  ### mir on cols, mrnas on rows of  corr_mat
    matched_targets = results$targets[colnames(corr_mat)] ### target mRNAs for selected miRNAs
    
     for (ci in  1:ncol(corr_mat)){
          mt = c(rownames(as.data.frame(matched_targets[colnames(corr_mat)[ci]])))
          non.t.mrna = setdiff(rownames(corr_mat),mt)
          corr_mat[non.t.mrna,ci]=NA
       } 
     # Define palette

     #Build the plot
rgb.palette <- colorRampPalette(c("cyan","blue","black","red","orange"), space = "rgb")
print(levelplot(t(corr_mat), aspect= "fill",main="mirna~mrna", xlab="miRNA", ylab="mRNA", scale = list(y = list(draw = F), x = list(draw=F)),col.regions=rgb.palette(299), at=seq(-0.8,0.8,0.1))
)


      ################################

      #### plot GT p-value bars for the heatmap
     setwd(paste(home_dir,"/Scripts_submitted/miRNA_mRNA_example/data",sep = ""))

     load(paste("fam",fam[i],"gt_pval_mrna_outcome.RData",sep=""))


     par(mfrow=c(4,1))
     plot(x=100,y=0.5,axes="F",ylim=c(0,1),xlim=c(0,length(raw.pval)))
     rect(0,-1,length(raw.pval),2,col="grey")
     abline(v=which(raw.pval<0.01),col="dark green")

     p.values <- p.adjust(raw.pval, method="BY")

     plot(x=100,y = 0.5,axes="F",ylim=c(0,1),xlim=c(0,length(p.values)))
     rect(0,-1,length(p.values),2,col="grey")
     abline(v=which(p.values<0.01),col="magenta")

     plot(x=3,y=0.5,,axes="F",ylim=c(0,1),xlim=c(0,5))
     rect(0,-1,1,2,col="dark green")
     rect(1.01,-1,2,2,col="dark green")
     rect(2.01,-1,3,2,col="dark green")
     rect(3.01,-1,4,2,col="dark green")
     rect(4.01,-1,5,2,col="grey")

     plot(x=3,y=0.5,,axes="F",ylim=c(0,1),xlim=c(0,5))
     rect(0,-1,1,2,col="magenta")
     rect(1.01,-1,2,2,col="magenta")
     rect(2.01,-1,3,2,col="magenta")
     rect(3.01,-1,4,2,col="magenta")
     rect(4.01,-1,5,2,col="grey")
}

dev.off()

