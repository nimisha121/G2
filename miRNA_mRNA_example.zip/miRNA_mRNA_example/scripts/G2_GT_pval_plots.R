############### Plot the p-values. PLOT 4 in the paper


home_dir = "/Users/chaturve/Dropbox/jelle_project/G2data_scripts_2"
setwd(paste(home_dir,"/Scripts_submitted/miRNA_mRNA_example/data",sep = ""))
load("fam_names_mi.m.rna.RData") 
load("Colon_miRNA_mRNA_overlaps.RData") # results

setwd(paste(home_dir,"/Scripts_submitted/miRNA_mRNA_example/results",sep = ""))
load("G2.pval_std.mirna.mrna.RData")
load("G2.TS_std.mirna.mrna.RData")

pdf("Figure4.pdf")

fam = c(13,21)  
#### 13 : miR-25 family
#### 21: miR-93 family

par(mfrow = c(2,2))

for (i in 1){
	
	
	 ### W&Y adjusted
    
     setwd(paste(home_dir,"/Scripts_submitted/miRNA_mRNA_example/scripts",sep = ""))

     source("W&Ymtc.R")
    
     adj_pval = WandY(TS_std,nperm = 1000)
     colr = rep("grey",length(adj_pval))
     colr[fam[i]] = "black"
   
     plot(adj_pval, ylim=c(0,1), pch=20, col=colr, main = "A",axes=F,xlab="miRNA families", ylab=paste("W&Y-corrected G2 p-values"))
     ax <- c(1:length(adj_pval))		
     axis(1, at=ax, labels=paste("f",seq(1:length(fam_names)),sep=""),cex.axis=0.61)
     ax = c(0,0.25,0.5,0.75,1)
     axis(2, at=ax,labels = ax,lwd=2)
     abline(h = 0.05,col = "black",lty = 2)
     abline(v = fam[i], lty=2,col="grey")
     
     colr = rep("grey",length(adj_pval))
     colr[fam[i+1]] = "black"
   
     plot(adj_pval, ylim=c(0,1), pch=20, col=colr, main = "B",axes=F,xlab="miRNA families", ylab=paste("W&Y-corrected G2 p-values"))
     ax <- c(1:length(adj_pval))		
     axis(1, at=ax, labels=paste("f",seq(1:length(fam_names)),sep=""),cex.axis=0.61)
     ax = c(0,0.25,0.5,0.75,1)
     axis(2, at=ax,labels = ax,lwd=2)
     abline(h = 0.05,col = "black",lty = 2)
     abline(v = fam[i+1], lty=2,col="grey")

    
    #### PLot GT raw and adj p-values
    
    setwd(paste(home_dir,"/Scripts_submitted/miRNA_mRNA_example/data",sep = ""))
    load(paste("fam",fam[i],"gt_pval_mrna_outcome.RData",sep=""))
    raw.pval = raw.pval[as.character(sort(as.numeric(names(raw.pval))))]

    plot(abs(log10(raw.pval)), axes= "F",ylim=c(0,10), xlim = c(0,length(raw.pval)),main="C", xlab="mRNA", ylab="-log10 GT p-values", pch=20, col="black")		
    ax <- seq(from = 0, to = 2252, length = 5)		
    axis(1, at=ax, labels=ax,cex.axis=0.61)
    ax = c(0,2.5,5,7.5,10)
    axis(2, at=ax,labels = ax,lwd=2)
    abline(h=abs(log10(0.05/(length(raw.pval)*22))), lty="dashed",col="black",lwd=1)
    
    
    setwd(paste(home_dir,"/Scripts_submitted/miRNA_mRNA_example/data",sep = ""))
    load(paste("fam",fam[i+1],"gt_pval_mrna_outcome.RData",sep=""))
    raw.pval = raw.pval[as.character(sort(as.numeric(names(raw.pval))))]

    plot(abs(log10(raw.pval)), axes= "F",ylim=c(0,10), xlim = c(0,length(raw.pval)),main="D", xlab="mRNA", ylab="-log10 GT p-values", pch=20, col="black")		
    ax <- seq(from = 0, to = length(raw.pval), length = 5)		
    axis(1, at=ax, labels=ax,cex.axis=0.61)
    ax = c(0,2.5,5,7.5,10)
    axis(2, at=ax,labels = ax,lwd=2)
    abline(h=abs(log10(0.05/(length(raw.pval)*22))), lty="dashed",col="black",lwd=1)

        ###########################################3

     
 }    

dev.off()

     