   WandY <- function(TS,nperm){
   	
   	ind.pval = TS    
    pval <- zscore <- numeric(nrow(ind.pval))
    names(pval)<- rownames(ind.pval)
    op = order(ind.pval[,1],decreasing=TRUE)
    ind.pval = ind.pval[op,]
    names(zscore)<-rownames(ind.pval)
    for (j in 1:(nrow(ind.pval)-1)){
        maxT = apply(ind.pval[(j:nrow(ind.pval)),2:(nperm+1)],2,max)
        zscore[j] = (sum(ind.pval[j,1] <= maxT))/nperm
     }
    zscore[nrow(ind.pval)] = (sum(ind.pval[nrow(ind.pval),1] <= ind.pval[nrow(ind.pval),-1]))/nperm
    zscore = cummax(zscore)
    for(k in 1:nrow(ind.pval)){pval[k] = zscore[names(pval)[k]]}
    adj_p = pval
    names(adj_p) = names(pval)
    return(adj_p)
   	
   }
   
   
    