rm(list = ls())

library(globaltest)

##### set the common folder path with this sub-folder structure inside it: 

#### common_folder -> small_region -> subfolders data and results
#### common_folder -> large_region -> subfolders data and results


path = "/svshare/nc/gt_mgt_comparison_sim/Simulations"

#### source the scripts
setwd(path)
source("Simulatedata.R")
source("G2.R")

######### Run the study for localized weak effects


##### Simulate the datasets and run the analysis
####### CN abbr in 50 percent of the samples and 5 percent of the probes 

num_samp = c(50,100)                               #### number of samples to be used
nsim = 100                                         #### number of simulations
np = 200                                           #### number of probes
cnabbr_mean = 1                                    #### Mean for generating CN abbr from a normal distribution
abbr_str = 101                                     #### Starting of the CN stretch with abbr
abbr_end = 110                                     #### End of the CN stretch with abbr
beta_mean = 2                                      #### Mean of the normal distribution for generating association parameter beta
beta_sd = 1                                        #### SD of the normal distribution for generating association parameter beta
sel_asso = c(0.2,0.8)                              #### Probability for selecting probes (these probes have CN abbr) that show association between GE and CN
nperm = 10000                                      #### Number of permutations for G2 and GT
pvalGT_small <- pvalG2_small <- matrix(0,nsim,length(num_samp))

for(i in 1:length(num_samp)){      
	
	pval = numeric(nsim)                           #### initiate the matrices
    pvalGT = matrix(0,np,nsim)
  
	for(k in 1:nsim){                               
		
		##### Generate the data and save it
		
		data_all = simdata(nprobe = np, nsamp = num_samp[i], cn_abbr_m = cnabbr_mean, str = abbr_str,end = abbr_end, beta_m = beta_mean ,beta_sd = beta_sd,sel_ge = sel_asso)
        setwd(paste(path,"/small_region/data",sep = ""))
		cgh = data_all$CN
		expr = data_all$GE
		ERinfo = data_all$ER
		coeffX = data_all$coeffX
        save(cgh,file = paste("cgh",k,"_nsamp",num_samp[i],".RData",sep=""))
        save(expr,file = paste("expr",k,"_nsamp",num_samp[i],".RData",sep=""))
        save(coeffX,file = paste("coeffX",k,"_nsamp",num_samp[i],".RData",sep=""))
        colnames(cgh) <- colnames(expr) <- as.character(1:ncol(expr))
        rownames(cgh) <- rownames(expr) <- as.character(1:nrow(expr))
        
        ####### Run G2

        G2pval = G2(dep.data = t(cgh), indep.data = t(expr),grouping=F, stand=TRUE, nperm=nperm)
        pval[k] = G2pval$std_pval

        ####### Run GT

        pval_gt = numeric(np)
        for (var in 1:nrow(cgh)){
          resp = cgh[i,]
          pval_gt[var] = p.value(gt(resp~t(expr),permutations = nperm))
         }
          pvalGT[,k] = pval_gt

	}
	
    setwd(paste(path,"/small_region/results",sep = ""))
    save(pval,file = paste("G2pval_numsamp",num_samp[i],".RData",sep = ""))
    save(pvalGT,file = paste("GTpval_numsamp",num_samp[i],".RData",sep = ""))
    
    ##### p-values for plotting
    pvalGT_small[,i] <- apply(apply(pvalGT,2,p.adjust,method = 'BH'),2,min)
    pvalG2_small[,i] <- pval
}

save(pvalGT_small,file = "pvalGT_small.RData")
save(pvalG2_small,file = "pvalG2_small.RData")

#############################################################################################################################################################################


######### Run the study for Widespread weak associations

##### Simulate the datasets and run the analysis
####### CN abbr in 50 percent of the samples and 20 percent of the probes 

num_samp = c(50,100)                               #### number of samples to be used
nsim = 100                                         #### number of simulations
np = 200                                           #### number of probes
cnabbr_mean = 1                                    #### Mean for generating CN abbr from a normal distribution
abbr_str = 101                                     #### Starting of the CN stretch with abbr
abbr_end = 140                                     #### End of the CN stretch with abbr
beta_mean = 0.2                                    #### Mean of the normal distribution for generating association parameter beta
beta_sd = 0.5                                      #### SD of the normal distribution for generating association parameter beta
sel_asso = c(0.2,0.8)                              #### Probability for selecting probes (these probes have CN abbr) that show association between GE and CN
nperm = 10000                                      #### Number of permutations for G2 and GT
pvalGT_large <- pvalG2_large <- matrix(0,nsim,length(num_samp))


for(i in 1:length(num_samp)){      
	
	pval = numeric(nsim)                           #### initiate the matrices
    pvalGT = matrix(0,np,nsim)

	for(k in 1:nsim){                               
		
		##### Generate the data and save it
		
		data_all = simdata(nprobe = np, nsamp = num_samp[i], cn_abbr_m = cnabbr_mean, str = abbr_str,end = abbr_end, beta_m = beta_mean ,beta_sd = beta_sd,sel_ge = sel_asso)
        setwd(paste(path,"/large_region/data",sep = ""))
		cgh = data_all$CN
		expr = data_all$GE
		ERinfo = data_all$ER
		coeffX = data_all$coeffX
        save(cgh,file = paste("cgh",k,"_nsamp",num_samp[i],".RData",sep=""))
        save(expr,file = paste("expr",k,"_nsamp",num_samp[i],".RData",sep=""))
        save(coeffX,file = paste("coeffX",k,"_nsamp",num_samp[i],".RData",sep=""))
        colnames(cgh) <- colnames(expr) <- as.character(1:ncol(expr))
        rownames(cgh) <- rownames(expr) <- as.character(1:nrow(expr))
        
        ####### Run G2

        G2pval = G2(dep.data = t(cgh), indep.data = t(expr),grouping=F, stand=TRUE, nperm=nperm)
        pval[k] = G2pval$std_pval

        ####### Run GT

        pval_gt = numeric(np)
        for (var in 1:nrow(cgh)){
          resp = cgh[i,]
          pval_gt[var] = p.value(gt(resp~t(expr),permutations = nperm))
         }
          pvalGT[,k] = pval_gt

	}
	
    setwd(paste(path,"/large_region/results",sep = ""))
    save(pval,file = paste("G2pval_numsamp",num_samp[i],".RData",sep = ""))
    save(pvalGT,file = paste("GTpval_numsamp",num_samp[i],".RData",sep = ""))
    
    ##### p-values for plotting
    pvalGT_large[,i] <- apply(apply(pvalGT,2,p.adjust,method = 'BH'),2,min)
    pvalG2_large[,i] <- pval
    
}

save(pvalGT_large,file = "pvalGT_large.RData")
save(pvalG2_large,file = "pvalG2_large.RData")

########################################################################################################################################################################################

########## Plot the results

setwd(paste(path,"/large_region/results",sep = ""))
load("pvalGT_large.RData")
load("pvalG2_large.RData")

setwd(paste(path,"/small_region/results",sep = ""))
load("pvalGT_small.RData")
load("pvalG2_small.RData")

setwd(path)
pdf("Simulation_G2.pdf")
par(xpd=F)

par(mfrow=c(2,2), mai = c(0.7, 0.6806, 0.7, 0.3486))

plot(x = pvalG2_small[,1],y = pvalGT_small[,1],xlim = c(0,1),ylim = c(0,1),col="grey",pch = 0 ,xlab = "G2 p-values",ylab = "GT p-values",main = " ")
abline(v = 0.05,lty = 2, col = "black")
abline(h = 0.05,lty = 2,col = "black")
par(xpd=TRUE)
text(y=1.3,x=0.5,"Localized strong associations",col="black",cex=1.2)
text(y=1.15,x=0.5,"A",col="black",cex=1.2)
text(y=1.2,x=1.2,"N     ",col="black",cex=1.5)
par(xpd=F)

plot(x = pvalG2_large[,1],y = pvalGT_large[,1],xlim = c(0,1),ylim = c(0,1),col="grey",pch = 0 ,xlab = "G2 p-values",ylab = "GT p-values",main = " ")
abline(v = 0.05,lty = 2, col = "black")
abline(h = 0.05,lty = 2,col = "black")
par(xpd=TRUE)
text(y=1.3,x=0.5,"Widespread weak associations",col="black",cex=1.2)
text(y=1.15,x=0.5,"B",col="black",cex=1.2)
text(y=1.2,x=-(0.23)," =  50",col="black",cex=1.5)

par(xpd=F)

plot(x = pvalG2_small[,2],y = pvalGT_small[,2],xlim = c(0,1),ylim = c(0,1),col="grey",pch = 0 ,xlab = "G2 p-values",ylab = "GT p-values",main = " ")
abline(v = 0.05,lty = 2, col = "black")
abline(h = 0.05,lty = 2,col = "black")
par(xpd=TRUE)
text(y=1.15,x=0.5,"C",col="black",cex=1.2)
text(y=1.2,x=1.2,"N     ",col="black",cex=1.5)
par(xpd=F)

plot(x = pvalG2_large[,2],y = pvalGT_large[,2],xlim = c(0,1),ylim = c(0,1),col="grey",pch = 0 ,xlab = "G2 p-values",ylab = "GT p-values",main = " ")
abline(v = 0.05,lty = 2, col = "black")
abline(h = 0.05,lty = 2,col = "black")
par(xpd=TRUE)
text(y=1.15,x=0.5,"D",col="black",cex=1.2)
text(y=1.2,x=-(0.22)," = 100",col="black",cex=1.5)
par(xpd=F)

dev.off()