
simdata <- function (nprobe, nsamp, cn_abbr_m,str,end,beta_m,beta_sd,sel_ge){
	##nprobe = number of probes
	##nsamp = number of samples
	##cn_abbr_m = mean for generating CN abbr
	##str and end = starting probe for and end probe of the CN stretch selected for recieveing CN abbr 
	##beta_m = mean for genrating beta values for GE asso with CN
	##beta_sd = sd for genrating beta values for GE asso with CN
    ##sel_ge = prob for selection of GE probes which will be associated with CN

####### CN data

a1 = sample(1:2, nsamp ,p=c(0.5,0.5),replace=T)

  a = a1
  X <- matrix(0,nprobe,(nsamp))

    for (cn in 1:(nsamp)){
     X[1:nprobe,cn] <- rnorm(nprobe,mean=0,sd=1)
    }

for (cn in 1:(nsamp)){



if(a[cn]==1){ 

      X[str:end,cn]<-rnorm(length(str:end),mean = cn_abbr_m ,sd=1)


      }

if(a[cn]==2){
      X[,cn]<-rnorm(nprobe,mean = 0 ,sd=1)
     }
 }
    ER = numeric(nsamp)
    ER[1:(nsamp/2)] = 1

    colnames(X) = as.character (1:ncol(X))
    rownames(X) = as.character (1:nrow(X))

data = X

##################################################################


# Gene expression data

ymat <- matrix(rnorm(nrow(data)*ncol(data),mean=0,sd=1),nrow=nrow(data),ncol=ncol(data))
coeffX <- matrix(0,nprobe,1)

coeffX[str:end,1]<- sample(c(0,1),length(str:end),p=sel_ge,replace=T)


for (ge in 1:nprobe){
     yexp = ymat[ge,]
     
     if(coeffX[ge]==1){
                      betaX = rnorm(1,mean=beta_m,sd=beta_sd)

                      ymat[ge,a1==1] =   ymat[ge,a1==1] + (data[ge,a1==1] * betaX)

           }
          }

return(list(CN = data,ER = ER, GE = ymat, coeffX = coeffX))

}


###########################################################################################
