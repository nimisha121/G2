####### Plot the G2 p-values for all pathways (Figure 2 in the paper)
setwd(paste(homedir,"/results",sep = ""))
pdf("Figure2.pdf")

allpath =  c("Wnt signaling pathway","Apoptosis","mTOR signaling pathway")  
chrm = c(1:22)
b=c("p","q")

#### Plots for chromosome arm 16q

ch = 16
ar = 2
   
adj_p = matrix(0,39,3)


##### Westfall and Young's correction method

 WandY <- function(TS,nperm){
   	ind.pval = TS    
    pval <- zscore <- numeric(nrow(ind.pval))
    names(pval)<- rownames(ind.pval)
    op = order(ind.pval[,1],decreasing=TRUE)
    ind.pval = ind.pval[op,]
    names(zscore)<-rownames(ind.pval)
    for (j in 1:(nrow(ind.pval)-1)){
        maxT = apply(ind.pval[(j:nrow(ind.pval)),2:(nperm+1)],2,max)
        zscore[j] = (sum(ind.pval[j,1] <= maxT))/nperm
     }
    zscore[nrow(ind.pval)] = (sum(ind.pval[nrow(ind.pval),1] <= ind.pval[nrow(ind.pval),-1]))/nperm
    zscore = cummax(zscore)
    for(k in 1:nrow(ind.pval)){pval[k] = zscore[names(pval)[k]]}
    adj_p = pval
    names(adj_p) = names(pval)
    return(adj_p)
   	
   }
   
####### Adjust G2 p-values for MTC   

for(path in 1:3){
load(paste(allpath[path],"_allsamps_G2TS_std.RData",sep=""))  ### G2 permutation test statistics. The G2 p-values and the test statistics is used for getting MTC G2 p-values
adjp = WandY(TS = TS_std,nperm = 1000)
adj_p[,path] = adjp[-27]

}
rownames(adj_p) = names(adjp)[-27]      

######## Get the GT p-values for all pathways

raw_p = matrix(0,61,3)
for(path in 1:3){
load(paste(allpath[path],"_",chrm[ch],b[ar],"gt_pval.RData",sep=""))  ### GT raw p-values
raw_p[,path] = abs(log10(raw.pval))
}

########## Plot the G2 and GT p-values	   

colr = matrix(rep("grey",nrow(adj_p)),nrow(adj_p),3)
colr[which(rownames(adj_p)==paste(chrm[ch],b[ar],sep="")),1] = "black"
colr[which(rownames(adj_p)==paste(chrm[ch],b[ar],sep="")),2] = "black"
colr[which(rownames(adj_p)==paste(chrm[ch],b[ar],sep="")),3] = "black"

par(mfrow = c(2,1))   
plot(adj_p[,1], ylim=c(0,1), pch=0, col=colr[,1], main = "A",axes=F,xlab="chromosome arms", ylab=paste("W&Y-corrected G2 p-values"))
points(adj_p[,2],pch = 19,col = colr[,2])
points(adj_p[,3],pch = 17, col = colr[,3])

ax <- c(1:nrow(adj_p))		
axis(1, at=ax, labels=rownames(adj_p),cex.axis=0.6)
ax = c(0,0.25,0.5,0.75,1)
axis(2, at=ax,labels = ax,lwd=2)
abline(h = 0.05,col = "black",lty = 2)
abline(v = 29,col = "black",lty = 2,lwd = 1)

colr = matrix(rep("grey",nrow(raw_p)),nrow(raw_p),3)

colr[,1] = "black"

plot(raw_p[,1], axes= "F",ylim=c(0,10), xlim = c(0,length(raw.pval)),main="B", xlab="copy number probes", ylab="-log10 GT p-values", pch=0, col=colr[,1])	
points(raw_p[,2],pch = 19,col = colr[,2])
points(raw_p[,3],pch = 17, col = colr[,3])
	
ax <- c(seq(1,length(raw.pval)))		
axis(1, at=ax, labels=ax,cex.axis=0.61)
ax = c(0,2.5,5,7.5,10)
axis(2, at=ax,labels = ax,lwd=2)
abline(h=abs(log10(0.05/(length(raw.pval)*39*3))), lty="dashed",col="black",lwd=1)

par(xpd = TRUE)
legend(-1,16,legend = c("mTOR","Apoptosis","Wnt"),pch = c(17,19,0),col = "grey",bty = "n")
legend(42,16,legend = c("mTOR (16q)","Apoptosis (16q)","Wnt (16q)"),pch = c(17,19,0),col = c("black","black","black"),bty = "n")
par(xpd = FALSE)

dev.off()