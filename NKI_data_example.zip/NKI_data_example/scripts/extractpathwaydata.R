rm(list=ls())
gc()

library(cgdsr)
library(biomaRt)
library(MASS)
library(KEGG.db)
setwd("/Users/chaturve/Dropbox/jelle_project/G2data_scripts_2/Scripts_submitted/NKI_data_example/data")

##########################################################################################################################################

# get list of human genes
ensembl = useMart("ENSEMBL_MART_ENSEMBL",dataset="hsapiens_gene_ensembl",host = "www.ensembl.org")
attributes = listAttributes(ensembl)
geneList <- getBM(attributes=c("ensembl_gene_id", "external_gene_name", "entrezgene", "chromosome_name", "start_position", "end_position", "percentage_gc_content"), mart = ensembl)

# remove all gene without entrezID
geneList <- geneList[!is.na(geneList[,3]),]

# remove all genes not mapping to chr 1 to 22 or X and Y
geneList <- geneList[which(geneList[,4] %in% c(1:22, "X", "Y")),]
geneList <- geneList[,-1]
geneList <- unique(geneList)
geneList <- geneList[order(geneList[,3], geneList[,4], geneList[,5]),]

##########################################################################################################################################
# 125, 100, 137, 141, 143, 145, 135
pathwayIDs <- c("hsa04210","hsa04310","hsa04150")  
pathwayNames <- c("Apoptosis", "Wnt signaling pathway", "mTOR signaling pathway")
KEGGno <- substr(pathwayIDs, 4, 8)

xx <- as.list(KEGGPATHID2EXTID)
xx <- xx[pathwayIDs]

##########################################################################################################################################

geneName = "genenames"
for (k in 1:length(pathwayIDs)){
	
	print(names(xx)[k])
	print(pathwayNames[k])
	
	geneName = "genenames"

	entrezIDs <- as.numeric(xx[[k]])
	ids <- match(entrezIDs, geneList[,2])
	entrezIDs <- entrezIDs[!is.na(ids)]
	ids <- match(entrezIDs, geneList[,2])
	GEdata <- numeric()
	gNames <- character()
	for (j in 1:length(ids)){
		geneName <- c(geneName,as.character(geneList[ids[j],1]))
		}
      geneName = geneName[-1]



################################ EXPR data  ##########################
load("nkiGE.RData") 
strpos = GEdata[,3]
chrom = GEdata[,2]
data.exp=GEdata

# read in the file
# query biomart
mart =  useMart("ENSEMBL_MART_ENSEMBL",dataset="hsapiens_gene_ensembl",host = "www.ensembl.org")

results <- getBM(attributes = c("ensembl_gene_id", "hgnc_symbol", "chromosome_name", "start_position", "end_position"), filters = "hgnc_symbol", values = geneName, mart = mart)
# sample results
if(any(is.na(as.numeric(results[,3])))){
a = which(is.na(as.numeric(results[,3])))
results = results[-a,]}
str = results[,4]
end = results[,5]
chrnam = results[,3]

GEid = as.data.frame(matrix(0,1,6))
colnames(GEid)=c("probeID","gene_names","chr","data_pos","strpos","endpos")
for(i in 1:length(str)){
    ls = str[i]
    le = end[i]
    ch = chrnam[i]
    if(any(strpos>=ls & strpos<=le & chrom==ch )){
    a = (which(strpos>=ls & strpos<=le & chrom==ch))[1]
    GEid = rbind(GEid,c(as.vector(data.exp[a,1]),as.vector(results[i,2]),as.vector(data.exp[a,2]),as.vector(data.exp[a,3]),ls,le))

}  }
GEid = GEid[-1,]
rownames(data.exp) = data.exp[,1]
data.exp = cbind(GEid,data.exp[GEid[,1],4:ncol(data.exp)] ) 
#rownames(data.exp) = data.exp[,2]

save(geneName, file = paste(pathwayNames[k],"_genelist.RData",sep=""))	
save(data.exp,file = paste("NKI_exp_",pathwayNames[k],".RData",sep=""))


}


