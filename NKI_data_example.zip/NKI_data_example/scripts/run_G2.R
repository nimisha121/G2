########## Run the G2 test on CN data (per chromosome arm) as dependent data and expression data (per pathway) as independent data

####### Read in CN data and pheno data

setwd(paste(homedir,"/data",sep = ""))
data1 =  read.csv("Supplementary_Table_S1 (1).csv") ### CN data
nainfo=is.na(data1)
data2=data1[-(which(apply(nainfo,1,sum)>((1/100)*ncol(data1)))),]
data2 = data2[,-2]
data2 = data2[,-4]

load("phenodata.RData") ## pheno data

### pathways to be considered

allpath =  c("Wnt signaling pathway","Apoptosis","mTOR signaling pathway")  

############ Run G2 per pathway (gene expression data) and per chromosome arm (CN data)

for(path in 1:length(allpath)){
	
	    ##### load gene expression data per pathway
	    
        setwd(paste(homedir,"/data",sep = ""))
        load(paste("NKI_exp_",allpath[path],".RData",sep=""))  ### load expression data
         
        data.exp = data.exp[!duplicated(data.exp[,2]),] 
        expr = data.exp[,-1]
        expr=expr[,-3]
        expr=expr[,-4]
        expr = expr[order(expr[,2]),]

        cgh = data2
        colnames(cgh) = colnames(expr)

        colnames(expr)[1:3] = c("probeid","chr","start")
        colnames(cgh)[1:3] = c("probeid","chr","start")
        samples = colnames(cgh)[4:71]

        ERinfo = as.vector(sinfo[,8]) ### Estrogen receptor status
        ERinfo = as.matrix(ERinfo)
        colnames(ERinfo) = "ER"
        ERinfo[ERinfo==1] = "Positive"
        ERinfo[ERinfo=="0"] = "Negative"
        
        ######### Get the chromosome arms

        chrm = c(1:22)
        b=c("p","q")
        crnam = as.vector(cgh[,1])
        l = table(cgh[,1])[which(table(cgh[,1])>1)]
        for (i in 1:length(l)){rnam = numeric(l[i])
             for(j in 1:l[i]){rnam[j] = paste(names(l)[i],"_",j,sep="")}
             crnam[which(crnam==as.character(names(l)[i]))[1]:which(crnam==as.character(names(l)[i]))[length(which(crnam==as.character(names(l)[i])))]]  = rnam
          }

        cgh[,1] = crnam

        data(chrom.table)
        
        ## Initialize
        
        p.val <- p.val_std <- c(0)
        TS <- TS_std <- numeric(1001)
        tt  = as.matrix(0,1,1)
        colnames(tt) = "elapsed"
        rownames(tt) = "z"
        
        
       #####  Divide the CN data per chromosome arm and run the analysis
        
       for(ch in 1:22){
            for(ar in 1:2){
            	
                start.5q <- chrom.table$start[as.vector(chrom.table$chr)==as.character(chrm[ch]) & as.vector(chrom.table$arm) == b[ar]]
                end.5q <- chrom.table$end[as.vector(chrom.table$chr)==as.character(chrm[ch]) & as.vector(chrom.table$arm) == b[ar]]

                pos.cgh = cgh$start[cgh$chr==chrm[ch]]

                cgh.c = 0
                cgh.id = numeric(1)
 
                for (i in 1:length(pos.cgh)){
                    if (pos.cgh[i]>=start.5q[1] && pos.cgh[i]<=end.5q[length(end.5q)] )
                      {cgh.c = cgh.c+1
                      cgh.id = c (cgh.id,which(cgh$chr==chrm[ch])[i])
                     }
                 }

                cgh.id = cgh.id[-1]
                check = (length(cgh.id)!=0)

                if(check == "TRUE"){

                  expr.6p = expr
                  cgh.6p = cgh[cgh.id,]

                  samples = colnames(expr.6p)[4:(ncol(expr.6p))]

                  rownames(cgh.6p) = as.vector(cgh.6p[,1])
                  rownames(expr.6p) = expr.6p[,1]

                  cgh.6p = cgh.6p[,4:(ncol(cgh.6p))]
                  expr.6p = expr.6p[,4:(ncol(expr.6p))]
                  
                  #### Run G2 
                  
                  st = proc.time()
                  G2pval = G2(dep.data = t(cgh.6p), indep.data = t(expr.6p),grouping=F, stand=TRUE, nperm=1000)
                  et = proc.time()
                  
                  #### get the correlation matrix
                  corr_mat = G2corr(dep.data = t(cgh.6p),indep.data = t(expr.6p))
                  
                  setwd(paste(homedir,"/results",sep = ""))
                  save(corr_mat,file = paste(allpath[path],"_",chrm[ch],b[ar],"corr_mat.RData",sep=""))
                  
                  t = et[3]-st[3]
                  t = t(as.matrix(t))
                  rownames(t) = paste(chrm[ch],b[ar],sep="")
                  tt = rbind(tt,t)
                  
                  pval = t(as.matrix(G2pval$G2p))
                  rownames(pval) = paste(chrm[ch],b[ar],sep="")
                  p.val = rbind(p.val,pval)
                  
                  pval = t(as.matrix(G2pval$std_pval))
                  rownames(pval) = paste(chrm[ch],b[ar],sep="")
                  p.val_std = rbind(p.val_std,pval)
                  
                  ts = G2pval$test_stat
                  rownames(ts) = paste(chrm[ch],b[ar],sep="")
                  TS = rbind(TS,ts)
                  
                  ts = G2pval$std_test
                  rownames(ts) = paste(chrm[ch],b[ar],sep="")
                  TS_std = rbind(TS_std,ts)
                  
                  
                  ############ Run GT
                  
                  cghGT = scale(t(cgh.6p),center = T, scale = T)
                  exprGT = scale(t(expr.6p),center = T, scale = T)
                  raw.pval = numeric(ncol(cghGT))
                  names(raw.pval) = colnames(cghGT)
                  for (ci in  1:ncol(cghGT)){
                     CNi = as.matrix(cghGT[,ci])
                     raw.pval[ci] = p.value(gt(CNi~exprGT))
                  }   
                   
                  setwd(paste(homedir,"/results",sep = ""))
                  save(raw.pval,file = paste(allpath[path],"_",chrm[ch],b[ar],"gt_pval.RData",sep=""))

                  #####################
                  
                  print(paste(chrm[ch],b[ar],sep = ""))
                  
                  
                }

             }
       }
       
       
p.val = p.val[-1,]
p.val_std = p.val_std[-1]
tt = tt[-1,]
TS = TS[-1,]
TS_std = TS_std[-1,]

setwd(paste(homedir,"/results",sep = ""))

save(p.val,file = paste(allpath[path],"_allsamps_G2pval.RData",sep="")) ### G2 p-values
save(p.val_std,file = paste(allpath[path],"_allsamps_G2pval_std.RData",sep="")) ### standardized G2 p-values

save(tt,file = paste(allpath[path],"_allsamps_comptime.RData",sep=""))  ### G2 run time

save(TS,file = paste(allpath[path],"_allsamps_G2TS.RData",sep=""))  ### G2 test statistics
save(TS_std,file = paste(allpath[path],"_allsamps_G2TS_std.RData",sep=""))  ### standardized G2 test statistics

}
##########################################################





