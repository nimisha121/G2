#################### G2 for NKI dataset (results and plots)

rm(list=ls())

library(SIM)
library(doBy)
library(reshape)
library(scales)
library(globaltest)
library(lattice)
library(gplots)
library(biomaRt)

##### set the common folder path with this sub-folder structure inside it: 

#### common folder -> subfolders: data, results and scripts 

homedir = "/Users/chaturve/Dropbox/jelle_project/G2data_scripts_2/Scripts_submitted/NKI_data_example"

#################################################################################################

#### Run G2 and GT

#### source the scripts

setwd(paste(homedir,"/scripts",sep = ""))
source("G2.R")
source("get_G2_corr_mat.R")
source("run_G2.R")

###############################################################################################
##### Plot Figure 2 in the paper
setwd(paste(homedir,"/scripts",sep = ""))
source("plot_for_paper_Fig2.R")

######################################################################################################################################################################################

##### Plot Figure 2 in the paper
setwd(paste(homedir,"/scripts",sep = ""))
source("plot_for_paper_Fig3.R")