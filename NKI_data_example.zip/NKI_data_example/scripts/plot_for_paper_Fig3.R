###### Plot the heatmap for 16q and Wnt pathway
allpath =  c("Wnt signaling pathway","Apoptosis","mTOR signaling pathway")  

chrm = c(1:22)
b=c("p","q")

#### Plots for chromosome arm 16q
ch = 16
ar = 2
path =  1

setwd(paste(homedir,"/results",sep = ""))
load(paste(allpath[path],"_",chrm[ch],b[ar],"corr_mat.RData",sep=""))

path_pval = matrix(0,40,length(allpath))
colnames(path_pval) = allpath
      
#### covariates heatmap
   
par(mfrow=c(1,1))

### get the chromosome arms 
mart <- useMart(biomart="ensembl", dataset="hsapiens_gene_ensembl")
   
results <- getBM(attributes = c("ensembl_gene_id", "hgnc_symbol", "chromosome_name", "strand","band","start_position", "end_position"), filters = "hgnc_symbol", values =  colnames(corr_mat), mart = mart)
   
a1 = which(is.na(as.numeric(results[,3])))
   
if(length(a1)>0){results = results[-a1,]}
   
chr = results[,3]
names(chr) = results[,2]
band = results[,5]
names(band) = results[,2]
chr = chr[colnames(corr_mat)]
band = band[colnames(corr_mat)]
colnames(corr_mat) = paste(colnames(corr_mat),"(",chr,substr(band,start=1,stop=1),")",sep="")

a = heatmap.2(corr_mat,density.info="none",trace="none")
corr_mat = corr_mat[,a$colInd]
corr_mat = corr_mat[a$rowInd,]

########################################################

# Define palette
trellis.device("pdf", height=10, width=10, file = "Figure3.pdf")

#Build the plot
   
rgb.palette <- colorRampPalette(c("red","orange","black","cyan","blue"), space = "rgb")
p1 = levelplot(corr_mat, aspect= "fill",main=" ", xlab="Copy Number (16q)", ylab="Gene Expression",
col.regions=rgb.palette(299), at=seq(-0.8,0.8,0.1),scale = list(y = list(cex = 0.6),x = list(cex = 0.4,rot=90)))
print(p1,panel.height=list(x=7,units="in"),panel.width=list(x=4.6,units="in"))     
dev.off()


